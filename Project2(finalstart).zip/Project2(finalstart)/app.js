const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const path = require('path'); // For handling file paths

const app = express();
const port = 3000; // Choose the port you want to run your server on

// Database connection parameters
const dbConfig = {
    host: '107.180.1.16',
    user: 'fall2023team2',
    password: 'fall2023team2',
    database: 'fall2023team2'
};

// Create a database connection pool
const pool = mysql.createPool(dbConfig);

// Middleware to parse JSON and form data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Serve the LoginScreen.html file for the root path ("/")
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Login.html'));
});

// Define routes for serving other HTML files (assuming they are in a "public" directory)
app.get('/create', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'SignUp.html'));
});
app.get('/home', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'MainPage.html'));
});

// Handle incoming data from your webpage to insert into LoginTable
app.post('/submit-data', (req, res) => {
    const { userName, passWord, email, mentorshipStatus } = req.body;

    // Validate user input (implement validation logic)

    // Execute an SQL query to insert data into LoginTable
    const query = 'INSERT INTO LoginTable (userName, passWord, email, mentorshipStatus) VALUES (?, ?, ?, ?)';

    pool.query(query, [userName, passWord, email, mentorshipStatus], (error, results) => {
        if (error) {
            console.error('Error inserting data:', error);
            res.status(500).send('Error inserting data');
        } else {
            console.log('Data inserted successfully');
            res.status(200).send('Data inserted successfully');
        }
    });
});

// Handle login form submission
app.post('/login', (req, res) => {
    const { userName, passWord } = req.body;

    // Query to check if the provided username and password match a record in the database
    const query = 'SELECT * FROM LoginTable WHERE userName = ? AND passWord = ?';
    
    pool.query(query, [userName, passWord], (error, results) => {
        if (error) {
            console.error('Error querying the database:', error);
            res.status(500).json({ error: 'Internal server error' });
        } else {
            if (results.length > 0) {
                // Username and password matched, redirect to Main Page
                res.redirect('/home');
            } else {
                // Username and password do not match, display a popup message
                res.status(401).json({ error: 'Invalid username or password' });
            }
        }
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});